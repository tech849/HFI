document.getElementById("wheel").innerHTML="<span onclick='#' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh2();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'id='myright'>&#10219</span><embed src='img/konark-wheel-1.jpg' width='100%' height=''></embed>";
function wh1(){
document.getElementById("wheel").innerHTML="<span onclick='#' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh2();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-1.jpg' width='100%' height=''></embed>";
}
function wh2(){
document.getElementById("wheel").innerHTML="<span onclick='wh1()' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh3();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-2.jpg' width='100%' height=''></embed>";
}
function wh3(){
document.getElementById("wheel").innerHTML="<span onclick='wh2();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh4();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-3.jpg' width='100%' height=''></embed>";

}
function wh4(){
document.getElementById("wheel").innerHTML="<span onclick='wh3();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh5();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-4.jpg' width='100%' height=''></embed>";

}
function wh5(){
document.getElementById("wheel").innerHTML="<span onclick='wh4();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh6();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-5.jpg' width='100%' height=''></embed>";

} 
function wh6(){
document.getElementById("wheel").innerHTML="<span onclick='wh5();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh7();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-6.jpg' width='100%' height=''></embed>";

} 
function wh7(){
document.getElementById("wheel").innerHTML="<span onclick='wh6();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh8();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-7.jpg' width='100%' height=''></embed>";

} 
function wh8(){
document.getElementById("wheel").innerHTML="<span onclick='wh7();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh9();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-8.jpg' width='100%' height=''></embed>";

} 
function wh9(){
document.getElementById("wheel").innerHTML="<span onclick='wh8();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh10();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-9.jpg' width='100%' height=''></embed>";

} 
function wh10(){
document.getElementById("wheel").innerHTML="<span onclick='wh9();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh11();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-10.jpg' width='100%' height=''></embed>";

} 
function wh11(){
document.getElementById("wheel").innerHTML="<span onclick='wh10();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh12();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-11.jpg' width='100%' height=''></embed>";

} 
function wh12(){
document.getElementById("wheel").innerHTML="<span onclick='wh11();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh13();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-12.jpg' width='100%'></embed>";
} 
function wh13(){
document.getElementById("wheel").innerHTML="<span onclick='wh12();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh14();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-13.jpg' width='100%' height=''></embed>";

} 
function wh14(){
document.getElementById("wheel").innerHTML="<span onclick='wh13();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh15();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-14.jpg' width='100%' height=''></embed>";

} 
function wh15(){
document.getElementById("wheel").innerHTML="<span onclick='wh14();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh16();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-15.jpg' width='100%' height=''></embed>";

} 
function wh16(){
document.getElementById("wheel").innerHTML="<span onclick='wh15();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh17();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-16.jpg' width='100%' height=''></embed>";

} 
function wh17(){
document.getElementById("wheel").innerHTML="<span onclick='wh16();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh18();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-17.jpg' width='100%' height=''></embed>";

} 
function wh18(){
document.getElementById("wheel").innerHTML="<span onclick='wh17();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh19();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-18.jpg' width='100%' height=''></embed>";

} 
function wh19(){
document.getElementById("wheel").innerHTML="<span onclick='wh18();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh20();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-19.jpg' width='100%' height=''></embed>";

} 
function wh20(){
document.getElementById("wheel").innerHTML="<span onclick='wh19();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh21();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-20.jpg' width='100%' height=''></embed>";

} 
function wh21(){
document.getElementById("wheel").innerHTML="<span onclick='wh20();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh22();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-21.jpg' width='100%' height=''></embed>";

} 
function wh22(){
document.getElementById("wheel").innerHTML="<span onclick='wh21();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh23();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-22.jpg' width='100%' height=''></embed>";

} 
function wh23(){
document.getElementById("wheel").innerHTML="<span onclick='wh22();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='wh24();' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-23.jpg' width='100%' height=''></embed>";

} 
function wh24(){
document.getElementById("wheel").innerHTML="<span onclick='wh23();' style='position:relative;top:600px;left:0px;background-color:transparent;color:yellow;font-size:130px;'id='myleft'>&#10218;</span>&ensp;&ensp;&ensp;&ensp;&ensp;<span onclick='' style='position:relative;top:600px;left:73%;background-color:transparent;color:yellow;font-size:130px;'id='myright'>&#10219</span><embed src='img/konark-wheel-24.jpg' width='100%' height=''></embed>";

}
