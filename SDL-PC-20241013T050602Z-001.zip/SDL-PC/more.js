function cate(){
document.getElementById("menu").innerHTML="<input type='radio'onclick='history();'onchange='history();'value='HISTORY'>HISTORY";
}